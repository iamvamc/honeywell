package com.honeywell.fitness.service;

import java.util.List;

import com.honeywell.fitness.entity.User;
import com.honeywell.fitness.vo.UserVO;

public interface UserService {
 public List<User> findCoaches(String role,String location);
 
 public User createUser(UserVO userVo);
}
