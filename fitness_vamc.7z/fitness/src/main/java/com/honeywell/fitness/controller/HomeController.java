package com.honeywell.fitness.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.honeywell.fitness.entity.User;
import com.honeywell.fitness.service.UserService;
import com.honeywell.fitness.vo.UserVO;

@Controller
public class HomeController {
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/", method = RequestMethod.GET)
    public String showWelcomePage(ModelMap model){
        return "home";
    }
	
	@RequestMapping(value="/register", method = RequestMethod.GET)
    public String showRegistrationPage(ModelMap model){
        return "registration";
    }
	
	@RequestMapping(value="/user", method = RequestMethod.POST)
    public String createUser(@ModelAttribute UserVO user,ModelMap map){
     User createUser = userService.createUser(user);
     if(createUser!=null){
    	 map.addAttribute("msg","User Created SucessFully");
    	 System.out.println(createUser.getFirstName());
     }
        return "home";
    }

	
	@RequestMapping("/users")
    public String home(Model model, @RequestParam String role, @RequestParam String location) {
         model.addAttribute("coaches", userService.findCoaches(role,location));
		return "listcoaches";
    }
	

}
